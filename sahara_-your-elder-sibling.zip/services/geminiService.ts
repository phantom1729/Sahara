
import { GoogleGenAI, GenerateContentResponse, Chat, Modality } from "@google/genai";
import { SISTER_SYSTEM_PROMPT, BROTHER_SYSTEM_PROMPT } from "../constants";
import { PersonaType } from "../types";

export class SaharaAI {
  private getClient() {
    return new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  }

  public async *streamMessage(persona: PersonaType, message: string, history: any[] = []) {
    const ai = this.getClient();
    const instruction = persona === PersonaType.SISTER ? SISTER_SYSTEM_PROMPT : BROTHER_SYSTEM_PROMPT;
    
    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: instruction,
        temperature: 0.7,
      },
    });

    try {
      const responseStream = await chat.sendMessageStream({ message });
      for await (const chunk of responseStream) {
        const c = chunk as GenerateContentResponse;
        yield c.text;
      }
    } catch (error) {
      console.error("Gemini Streaming Error:", error);
      yield "Darr mat, main hoon. Kuch technical error hua hai par hum baat karte rahenge.";
    }
  }

  public connectLive(persona: PersonaType, callbacks: any) {
    const ai = this.getClient();
    const isSister = persona === PersonaType.SISTER;
    
    const instruction = isSister 
      ? SISTER_SYSTEM_PROMPT + "\nIMPORTANT: Tum ek badi behen (Female) ho. Tumhari awaaz pyari aur sukoon bhari honi chahiye. User ko 'Meri pyari behen' ya 'Beta' keh kar sambodhit kar sakti ho. Unki har baat dhairya se suno."
      : BROTHER_SYSTEM_PROMPT + "\nIMPORTANT: Tum ek bada bhai (Male) ho. Tumhari awaaz bharosemand aur mazboot honi chahiye. User ko 'Chhoti' ya 'Mere bhai' keh kar support do. Pehle unhe bolne do, beech mein mat toko.";

    return ai.live.connect({
      model: 'gemini-2.5-flash-native-audio-preview-12-2025',
      callbacks,
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { 
              // Kore = Female, Puck = Male
              voiceName: isSister ? 'Kore' : 'Puck' 
            },
          },
        },
        systemInstruction: instruction,
      },
    });
  }
}
