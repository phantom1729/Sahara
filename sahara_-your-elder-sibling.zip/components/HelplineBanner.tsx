
import React from 'react';

// This component is now empty as per the user's request to remove the top numbers.
export const HelplineBanner: React.FC = () => {
  return null;
};
